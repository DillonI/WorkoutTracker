import { GoogleGenAI } from "@google/genai";
import { WorkoutSession, SetLog } from '../types';

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({ apiKey });
};

export const generateWorkoutAnalysis = async (
  session: WorkoutSession
): Promise<string> => {
  const ai = getClient();
  if (!ai) return "API Key missing. Please configure your environment.";

  // Format the data for the prompt
  const exercisesText = session.logs.map(log => {
    const setDetails = log.sets.map(s => {
      const type = s.isDropSet ? "DROP SET" : "Main Set";
      return `   - ${type} ${s.setNumber}: ${s.weight}lbs x ${s.reps} reps (Target: ${s.targetReps})`;
    }).join('\n');
    
    return `Exercise: ${log.exerciseName}\n${setDetails}`;
  }).join('\n\n');

  const prompt = `
    You are an expert strength and conditioning coach specializing in a "Double Progression" algorithm with "Metabolic Drop Sets".
    Analyze the following workout data and provide progression recommendations for the NEXT workout based on these specific logic rules:

    LOGIC RULES:
    1. SUCCESS: If user hit all reps at top weight for all sets -> Recommend increasing weight by 5 lbs. Status: "Progressive Overload Achieved".
    2. NEAR MISS: If user missed by 1-2 reps total across top sets -> Keep weight same. Status: "Retry: Close call".
    3. FAILURE WITH DROP SET: If user failed a main set and used a drop set:
       - If early sets (1 or 2) failed significantly -> Recommend Lowering Weight (Deload).
       - If only last set failed but volume was saved via drop set -> Keep Weight Same. Status: "Volume Save".

    WORKOUT DATA:
    ${exercisesText}

    OUTPUT FORMAT:
    Return a concise bulleted list. For each exercise where a decision is clear, provide the specific recommendation.
    Keep the tone encouraging but technical.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: "You are a succinct, data-driven strength coach.",
      }
    });
    return response.text || "Could not generate analysis.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error connecting to AI Coach. Please check your network or API key.";
  }
};